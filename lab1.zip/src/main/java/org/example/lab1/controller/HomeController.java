package org.example.lab1.controller;


import org.example.lab1.model.Usuario;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HomeController {

    @GetMapping("/ingresar")
    public String form() {return "ingresar";}

    @PostMapping("/ingresar")
    public String guardar(Usuario usuario, Model model){
        model.addAttribute("modo", "datos");
        model.addAttribute("resultado", "nombre=" + usuario.getNombre() +", tipo=" + usuario.getTipo() + ", codigo=" + usuario.getCodigo() + ", fecha=" + usuario.getFecha());

        return "result";

    }
}
