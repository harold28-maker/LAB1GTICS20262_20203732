package org.example.lab1.model;


public class Usuario {
    private String nombre;
    private String tipo;
    private String codigo;
    private String fecha;


    public Usuario(String nombre, String tipo, String codigo, String fecha) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.codigo = codigo;
        this.fecha = fecha;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}
